The link to view my website is: http://sgiorlando.github.io/A9/index.html

or you could also use: http://sgiorlando.github.io/A9/sgiorlan_assign9.html

To download all my files you can use: http://sgiorlando.github.io/A9/sgiorlan_assign9.zip



This game of scrabble mostly works, I have a board and I check to see if the words are valid from a dictionary or not.  This was my attempt at it.